package com.yeditepe.acm412;

public class DBTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Create instance of DBConnect object
         DBConnect db1=new DBConnect();
	    System.out.println(db1.getData());
	}

}
