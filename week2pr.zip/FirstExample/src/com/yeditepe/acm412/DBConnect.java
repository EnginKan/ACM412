package com.yeditepe.acm412;
import java.sql.*;
public class DBConnect {
	//required url for database connection
	String db_url="jdbc:mysql://localhost:3306/test?"
			+ "useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&"
			+ "serverTimezone=UTC";
	String username="root";
	String password="";//empty password for default root user
	String driver_name="com.mysql.cj.jdbc.Driver";
	//Connection object reference to create connection by using Driver Manager
	Connection connection;		
   
	//constructor for Database Connection
	public DBConnect(){
		//1.Step include Driver Class
		try{
		Class.forName(driver_name);
		//2.step: Create Connection using DriverManager
		connection=DriverManager.getConnection(db_url, username, password);
		System.out.println("Connection Successfull!!");
		}
		catch(ClassNotFoundException er){
			System.out.println("Class Error:"+er.getMessage());
		}
		catch(SQLException e){
			System.out.println("SQL Error Message="+e.getMessage());
		}
				}
	
	//to write a sql statement
	public  String getData(){
		String data="";
		String sorgu="Select * from users";
		//To run an sql query on database we need Statement object in our code
		try {
			Statement st=connection.createStatement();
			//to get data from database we use ResultSet object tostore data from database
			ResultSet cevap=st.executeQuery(sorgu);
			//To process data comes from database we use our ResultSet object like an iterator
			while(cevap.next()){
				data+="ID: "+cevap.getInt("user_id")
				           +" Name: "+cevap.getString("name")
				           +" Surname "+cevap.getString("surname")
				           +" Email: "+cevap.getString("email")+"\n";
			}//We read the ResultSet object
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return data;
	}
		
		
	}
	

